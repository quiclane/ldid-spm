#pragma once
#ifdef __cplusplus
extern "C" {
#endif
int ldid_version(void);
#ifdef __cplusplus
}
#endif
